"""
Ephemeris backend abstraction for BaZi Engine.

Provides SwissEphBackend with automatic fallback:
  1. Swiss Ephemeris data files (FLG_SWIEPH) — highest precision (~0.001")
  2. Built-in Moshier analytical ephemeris (FLG_MOSEPH) — still <1" accuracy

The Moshier fallback requires NO external files and covers 3000 BC - 3000 AD.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from functools import lru_cache
from pathlib import Path
from typing import Optional, Protocol
import os
import logging

import swisseph as swe

logger = logging.getLogger(__name__)


def norm360(deg: float) -> float:
    """Normalize angle to [0, 360)."""
    x = deg % 360.0
    if x < 0:
        x += 360.0
    return x


def wrap180(deg: float) -> float:
    """Wrap angle to [-180, +180)."""
    return (deg + 180.0) % 360.0 - 180.0


class EphemerisBackend(Protocol):
    """Protocol for any ephemeris backend."""
    def delta_t_seconds(self, jd_ut: float) -> float: ...
    def jd_tt_from_jd_ut(self, jd_ut: float) -> float: ...
    def sun_lon_deg_ut(self, jd_ut: float) -> float: ...
    def solcross_ut(self, target_lon_deg: float, jd_start_ut: float) -> Optional[float]: ...


# -- Ephemeris file resolution --

EPHEMERIS_FILES_REQUIRED = [
    "sepl_18.se1",
    "semo_18.se1",
    "seas_18.se1",
    "seplm06.se1",
]


def _resolve_ephe_path(ephe_path: Optional[str]) -> Path:
    """Resolve the ephemeris data directory (no downloads)."""
    if ephe_path:
        return Path(ephe_path)
    env = os.environ.get("SE_EPHE_PATH")
    if env:
        return Path(env)
    return Path.home() / ".cache" / "bazi_engine" / "swisseph"


def _check_ephemeris_files(ephe_path: Optional[str]) -> Optional[str]:
    """
    Check if SE data files exist.  Returns resolved path string if all
    files present, None otherwise.  Never downloads anything.
    """
    path = _resolve_ephe_path(ephe_path)
    path.mkdir(parents=True, exist_ok=True)
    missing = [n for n in EPHEMERIS_FILES_REQUIRED if not (path / n).exists()]
    if missing:
        return None
    return str(path)


# -- Swiss Ephemeris backend --

@dataclass(frozen=True)
class SwissEphBackend:
    """
    Swiss Ephemeris calculation backend.

    Automatically selects the best available mode:
      - FLG_SWIEPH if data files are present (highest precision)
      - FLG_MOSEPH (Moshier) as built-in fallback (< 1 arcsec)

    The selected mode is stored in `flags` and `mode` for transparency.
    """
    flags: int = swe.FLG_SWIEPH
    ephe_path: Optional[str] = None
    mode: str = "swieph"

    def __post_init__(self) -> None:
        resolved = _check_ephemeris_files(self.ephe_path)
        if resolved is not None:
            swe.set_ephe_path(resolved)
            object.__setattr__(self, 'flags', swe.FLG_SWIEPH)
            object.__setattr__(self, 'mode', 'swieph')
            logger.info("Ephemeris: Swiss Ephemeris data files at %s", resolved)
        else:
            swe.set_ephe_path('')
            object.__setattr__(self, 'flags', swe.FLG_MOSEPH)
            object.__setattr__(self, 'mode', 'moshier')
            logger.info("Ephemeris: Moshier analytical fallback (no SE files found)")

    # -- Core calculations --

    def delta_t_seconds(self, jd_ut: float) -> float:
        """Delta-T = TT - UT in seconds."""
        return swe.deltat(jd_ut) * 86400.0

    def jd_tt_from_jd_ut(self, jd_ut: float) -> float:
        """Convert JD(UT) to JD(TT)."""
        return jd_ut + swe.deltat(jd_ut)

    def sun_lon_deg_ut(self, jd_ut: float) -> float:
        """Apparent geocentric Sun longitude (ecliptic, degrees)."""
        (lon, *_), _ret = swe.calc_ut(jd_ut, swe.SUN, self.flags)
        return norm360(lon)

    def solcross_ut(self, target_lon_deg: float, jd_start_ut: float) -> Optional[float]:
        """JD(UT) when Sun crosses target_lon_deg after jd_start_ut."""
        return swe.solcross_ut(target_lon_deg, jd_start_ut, self.flags)

    def calc_body_ut(self, jd_ut: float, body_id: int) -> dict:
        """
        Calculate any celestial body position.

        For bodies that require SE data files (e.g. Chiron in Moshier mode),
        automatically falls back to a Keplerian orbit approximation.

        Returns dict with: longitude, latitude, distance, speed,
        is_retrograde, zodiac_sign, degree_in_sign, source.
        """
        try:
            flags = self.flags | swe.FLG_SPEED
            (lon, lat, dist, speed_lon, _, _), _ret = swe.calc_ut(
                jd_ut, body_id, flags
            )
            return {
                "longitude": norm360(lon),
                "latitude": lat,
                "distance": dist,
                "speed": speed_lon,
                "is_retrograde": speed_lon < 0,
                "zodiac_sign": int(lon // 30),
                "degree_in_sign": lon % 30,
                "source": "swisseph",
            }
        except swe.Error:
            # Fallback: Keplerian approximation for known minor bodies
            if body_id == swe.CHIRON:
                return _keplerian_chiron(jd_ut)
            return {"error": f"Body {body_id} unavailable (no SE data, no fallback)"}

    def calc_houses(self, jd_ut: float, lat: float, lon: float) -> dict:
        """
        Calculate house cusps and angles with fallback chain:
        Placidus -> Porphyry -> Whole Sign.
        """
        house_systems = [b'P', b'O', b'W']
        for sys_char in house_systems:
            try:
                cusps_raw, ascmc = swe.houses(jd_ut, lat, lon, sys_char)
                if len(cusps_raw) >= 12 and not (cusps_raw[1] == 0.0 and cusps_raw[2] == 0.0):
                    cusps = {}
                    if len(cusps_raw) == 12:
                        for i in range(12):
                            cusps[str(i + 1)] = cusps_raw[i]
                    else:
                        for i in range(1, 13):
                            cusps[str(i)] = cusps_raw[i]
                    angles = {
                        "Ascendant": ascmc[0],
                        "MC": ascmc[1],
                        "Vertex": ascmc[3] if len(ascmc) > 3 else 0.0,
                    }
                    return {
                        "cusps": cusps,
                        "angles": angles,
                        "house_system": sys_char.decode('utf-8'),
                    }
            except swe.Error:
                continue
        raise RuntimeError("House calculation failed with all systems (P/O/W)")


# -- Julian Day conversions --

def datetime_utc_to_jd_ut(dt_utc: datetime) -> float:
    """Convert aware UTC datetime -> JD(UT)."""
    if dt_utc.tzinfo is None or dt_utc.utcoffset() != timedelta(0):
        raise ValueError("Expected aware UTC datetime")
    h = (dt_utc.hour
         + dt_utc.minute / 60.0
         + (dt_utc.second + dt_utc.microsecond / 1e6) / 3600.0)
    return swe.julday(dt_utc.year, dt_utc.month, dt_utc.day, h)


def jd_ut_to_datetime_utc(jd_ut: float) -> datetime:
    """Convert JD(UT) -> aware UTC datetime."""
    y, m, d, h = swe.revjul(jd_ut)
    hour = int(h)
    rem = (h - hour) * 3600.0
    minute = int(rem // 60.0)
    sec = rem - minute * 60.0
    second = int(sec)
    micro = int(round((sec - second) * 1_000_000))
    if micro >= 1_000_000:
        micro -= 1_000_000
        second += 1
    if second >= 60:
        second -= 60
        minute += 1
    if minute >= 60:
        minute -= 60
        hour += 1
    base = datetime(y, m, d, 0, 0, 0, 0, tzinfo=timezone.utc)
    return base + timedelta(hours=hour, minutes=minute, seconds=second,
                            microseconds=micro)


# -- Keplerian orbit solver for Chiron fallback --
#
# When SE asteroid files are unavailable (Moshier mode), we compute
# Chiron's position from J2000.0 osculating orbital elements.
# Accuracy: ~1-2 deg over 1950-2100 (sufficient for Wu-Xing element mapping).
# For sub-arcsecond precision, use SE data files.

import math as _math

# Chiron osculating elements at J2000.0 (JD 2451545.0)
# Source: JPL Horizons / MPC
_CHIRON_EPOCH_JD = 2451545.0   # J2000.0
_CHIRON_A  = 13.6481           # Semi-major axis (AU)
_CHIRON_E  = 0.37884           # Eccentricity
_CHIRON_I  = 6.931             # Inclination (deg)
_CHIRON_OM = 209.232           # Longitude of ascending node (deg)
_CHIRON_W  = 339.557           # Argument of perihelion (deg)
_CHIRON_M0 = 68.944            # Mean anomaly at epoch (deg)
_CHIRON_N  = 0.01942           # Mean motion (deg/day)


def _solve_kepler(M_rad: float, e: float, tol: float = 1e-12) -> float:
    """Solve Kepler equation M = E - e*sin(E) via Newton-Raphson."""
    E = M_rad  # initial guess
    for _ in range(50):
        dE = (E - e * _math.sin(E) - M_rad) / (1.0 - e * _math.cos(E))
        E -= dE
        if abs(dE) < tol:
            break
    return E


def _keplerian_chiron(jd_ut: float) -> dict:
    """
    Compute Chiron geocentric ecliptic position from Keplerian elements.

    Steps:
      1. Propagate mean anomaly from J2000.0
      2. Solve Kepler equation for eccentric anomaly
      3. Compute heliocentric ecliptic coordinates
      4. Subtract Earth's heliocentric position (from Sun's geocentric)
         to get geocentric coordinates
      5. Estimate speed from 1-day finite difference
    """
    rad = _math.radians
    deg = _math.degrees

    dt_days = jd_ut - _CHIRON_EPOCH_JD
    M_deg = (_CHIRON_M0 + _CHIRON_N * dt_days) % 360.0
    M_rad = rad(M_deg)

    # Eccentric anomaly
    E = _solve_kepler(M_rad, _CHIRON_E)

    # True anomaly
    nu = 2.0 * _math.atan2(
        _math.sqrt(1.0 + _CHIRON_E) * _math.sin(E / 2.0),
        _math.sqrt(1.0 - _CHIRON_E) * _math.cos(E / 2.0),
    )

    # Radius
    r = _CHIRON_A * (1.0 - _CHIRON_E * _math.cos(E))

    # Heliocentric position in orbital plane
    x_orb = r * _math.cos(nu)
    y_orb = r * _math.sin(nu)

    # Rotate to ecliptic frame
    w = rad(_CHIRON_W)
    om = rad(_CHIRON_OM)
    i = rad(_CHIRON_I)

    cos_w, sin_w = _math.cos(w), _math.sin(w)
    cos_om, sin_om = _math.cos(om), _math.sin(om)
    cos_i, sin_i = _math.cos(i), _math.sin(i)

    # Orbital plane -> ecliptic
    x_rot = x_orb * cos_w - y_orb * sin_w
    y_rot = x_orb * sin_w + y_orb * cos_w

    x_ecl = x_rot * cos_om - y_rot * cos_i * sin_om
    y_ecl = x_rot * sin_om + y_rot * cos_i * cos_om
    z_ecl = y_rot * sin_i

    # Geocentric correction: Earth position = -(Sun geocentric position)
    # Sun is always available in Moshier
    try:
        (sun_lon, sun_lat, sun_dist, *_), _ = swe.calc_ut(
            jd_ut, swe.SUN, swe.FLG_MOSEPH
        )
        # Earth heliocentric = opposite of Sun geocentric
        earth_lon_rad = rad(sun_lon + 180.0)
        earth_lat_rad = rad(-sun_lat)
        ex = sun_dist * _math.cos(earth_lat_rad) * _math.cos(earth_lon_rad)
        ey = sun_dist * _math.cos(earth_lat_rad) * _math.sin(earth_lon_rad)
        ez = sun_dist * _math.sin(earth_lat_rad)

        # Geocentric Chiron
        gx = x_ecl - ex
        gy = y_ecl - ey
        gz = z_ecl - ez
    except swe.Error:
        # If even Sun fails, use heliocentric
        gx, gy, gz = x_ecl, y_ecl, z_ecl

    geo_lon = deg(_math.atan2(gy, gx)) % 360.0
    geo_lat = deg(_math.atan2(gz, _math.sqrt(gx * gx + gy * gy)))
    geo_dist = _math.sqrt(gx * gx + gy * gy + gz * gz)

    # Speed estimate via 1-day finite difference
    lon_tomorrow = _keplerian_chiron_lon_only(jd_ut + 1.0)
    speed_lon = (lon_tomorrow - geo_lon + 180.0) % 360.0 - 180.0

    return {
        "longitude": norm360(geo_lon),
        "latitude": geo_lat,
        "distance": geo_dist,
        "speed": speed_lon,
        "is_retrograde": speed_lon < 0,
        "zodiac_sign": int(geo_lon // 30),
        "degree_in_sign": geo_lon % 30,
        "source": "keplerian_fallback",
    }


def _keplerian_chiron_lon_only(jd_ut: float) -> float:
    """Quick geocentric longitude for Chiron (for speed estimation)."""
    rad = _math.radians

    dt_days = jd_ut - _CHIRON_EPOCH_JD
    M_rad = rad((_CHIRON_M0 + _CHIRON_N * dt_days) % 360.0)
    E = _solve_kepler(M_rad, _CHIRON_E)
    nu = 2.0 * _math.atan2(
        _math.sqrt(1.0 + _CHIRON_E) * _math.sin(E / 2.0),
        _math.sqrt(1.0 - _CHIRON_E) * _math.cos(E / 2.0),
    )
    r = _CHIRON_A * (1.0 - _CHIRON_E * _math.cos(E))

    x_orb = r * _math.cos(nu)
    y_orb = r * _math.sin(nu)

    w = rad(_CHIRON_W)
    om = rad(_CHIRON_OM)
    i = rad(_CHIRON_I)
    x_rot = x_orb * _math.cos(w) - y_orb * _math.sin(w)
    y_rot = x_orb * _math.sin(w) + y_orb * _math.cos(w)
    x_ecl = x_rot * _math.cos(om) - y_rot * _math.cos(i) * _math.sin(om)
    y_ecl = x_rot * _math.sin(om) + y_rot * _math.cos(i) * _math.cos(om)

    try:
        (sun_lon, sun_lat, sun_dist, *_), _ = swe.calc_ut(
            jd_ut, swe.SUN, swe.FLG_MOSEPH
        )
        el = rad(sun_lon + 180.0)
        eb = rad(-sun_lat)
        ex = sun_dist * _math.cos(eb) * _math.cos(el)
        ey = sun_dist * _math.cos(eb) * _math.sin(el)
        x_ecl -= ex
        y_ecl -= ey
    except swe.Error:
        pass

    return _math.degrees(_math.atan2(y_ecl, x_ecl)) % 360.0


# -- Legacy shim --

@lru_cache(maxsize=1)
def ensure_ephemeris_files(ephe_path: Optional[str] = None) -> str:
    """
    Legacy shim.  Returns resolved path (may be empty string for Moshier).
    """
    resolved = _check_ephemeris_files(ephe_path)
    if resolved is not None:
        return resolved
    logger.warning("SE data files not found - Moshier fallback active")
    return ''
