"""
FusionAstrology — Wu-Xing + Western Fusion Analysis.

Implements:
  - Planet-to-Element mapping (Wu Xing)
  - Wu-Xing 5-dimensional vectors from BaZi and Western charts
  - Harmony Index (cosine similarity)
  - Elemental Balance (Shannon entropy)
  - Equation of Time / True Solar Time
  - Night-chart-aware Mercury sect assignment

Changelog vs. prior version:
  - FIX: NorthNode counted only once (TrueNorthNode removed from mapping)
  - FIX: Night chart detection receives Ascendant from western chart
  - FIX: cosmic_state replaced by elemental_balance (Shannon entropy —
         genuinely different metric from harmony_index)
  - FIX: calculate_wuxing_from_bazi uses direct list mutation (no
         per-iteration object creation)
"""
from __future__ import annotations
from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass
from math import sin, cos, radians, degrees, pi, sqrt, floor, log2

# =============================================================================
# PLANET -> WU-XING ELEMENT MAPPING
# =============================================================================
# Only NorthNode is included — TrueNorthNode was a duplicate that inflated
# Wood by +1.0 in every chart.  NorthNode now uses swe.TRUE_NODE in
# western.py for orbital accuracy, but is counted once.

PLANET_TO_WUXING = {
    "Sun": "Feuer",                    # Fire
    "Moon": "Wasser",                  # Water
    "Mercury": ["Erde", "Metall"],     # Dual: Earth (day) / Metal (night)
    "Venus": "Metall",                 # Metal
    "Mars": "Feuer",                   # Fire
    "Jupiter": "Holz",                 # Wood
    "Saturn": "Erde",                  # Earth
    "Uranus": "Holz",                  # Wood (innovation / sudden change)
    "Neptune": "Wasser",               # Water
    "Pluto": "Feuer",                  # Fire (transformation)
    "Chiron": "Wasser",                # Water (healing)
    "Lilith": "Wasser",               # Water (instincts)
    "NorthNode": "Holz",              # Wood (growth path)
}

# Element order for vector representation (Wu Xing generation cycle)
WUXING_ORDER = ["Holz", "Feuer", "Erde", "Metall", "Wasser"]
WUXING_INDEX = {elem: i for i, elem in enumerate(WUXING_ORDER)}


# =============================================================================
# WU-XING VECTOR CLASS
# =============================================================================

@dataclass
class WuXingVector:
    """5-dimensional elemental distribution vector."""
    holz: float
    feuer: float
    erde: float
    metall: float
    wasser: float

    def to_list(self) -> List[float]:
        return [self.holz, self.feuer, self.erde, self.metall, self.wasser]

    def to_dict(self) -> Dict[str, float]:
        return {
            "Holz": self.holz, "Feuer": self.feuer, "Erde": self.erde,
            "Metall": self.metall, "Wasser": self.wasser,
        }

    def magnitude(self) -> float:
        """L2 norm."""
        return sqrt(sum(x ** 2 for x in self.to_list()))

    def normalize(self) -> WuXingVector:
        """Unit vector (L2)."""
        mag = self.magnitude()
        if mag == 0:
            return self
        return WuXingVector(*[x / mag for x in self.to_list()])

    def total(self) -> float:
        """Sum of all components."""
        return sum(self.to_list())

    def proportions(self) -> List[float]:
        """L1-normalized: each element as fraction of total."""
        t = self.total()
        if t == 0:
            return [0.0] * 5
        return [x / t for x in self.to_list()]

    @staticmethod
    def zero() -> WuXingVector:
        return WuXingVector(0, 0, 0, 0, 0)


# =============================================================================
# NIGHT CHART DETECTION
# =============================================================================

def is_night_chart(sun_longitude: float, ascendant: Optional[float] = None) -> bool:
    """
    Determine if this is a night chart.

    Night = Sun below horizon = Sun in houses 1-6.
    Geometrically: Sun is between Descendant and Ascendant going
    counter-clockwise through the lower hemisphere.

    Args:
        sun_longitude: Sun's ecliptic longitude (0-360 deg)
        ascendant: Ascendant degree.  REQUIRED for meaningful result.

    Returns:
        True if night chart.  Returns False if ascendant is None
        (day chart assumption when data is unavailable).
    """
    if ascendant is None:
        return False

    dsc = (ascendant + 180.0) % 360.0

    # Sun below horizon: between DSC and ASC (counter-clockwise)
    if ascendant > dsc:
        return dsc <= sun_longitude < ascendant
    else:
        return sun_longitude >= dsc or sun_longitude < ascendant


# =============================================================================
# PLANET -> WU-XING VECTOR
# =============================================================================

def planet_to_wuxing(planet_name: str, is_night: bool = False) -> str:
    """Get Wu-Xing element for a planet.  Mercury switches by sect."""
    element = PLANET_TO_WUXING.get(planet_name, "Erde")
    if isinstance(element, list):
        return element[1] if is_night else element[0]
    return element


def calculate_wuxing_vector_from_planets(
    bodies: Dict[str, Dict[str, Any]],
    ascendant: Optional[float] = None,
    use_retrograde_weight: bool = False,
) -> WuXingVector:
    """
    Calculate Wu-Xing vector from planetary positions.

    Args:
        bodies: planet -> {longitude, is_retrograde, ...}
        ascendant: Ascendant degree for night-chart detection.
            Without it, Mercury always maps to Earth (day chart).
        use_retrograde_weight: If True, retrograde planets get 1.3x weight.
            Off by default — no traditional Wu-Xing basis for this.

    Returns:
        Raw (un-normalized) WuXingVector.
    """
    values = [0.0, 0.0, 0.0, 0.0, 0.0]

    sun_data = bodies.get("Sun", {})
    sun_lon = sun_data.get("longitude", 0.0)
    night = is_night_chart(sun_lon, ascendant)

    for planet, data in bodies.items():
        if "error" in data:
            continue

        element = planet_to_wuxing(planet, night)
        weight = 1.0
        if use_retrograde_weight and data.get("is_retrograde", False):
            weight = 1.3

        values[WUXING_INDEX[element]] += weight

    return WuXingVector(*values)


# =============================================================================
# BAZI -> WU-XING VECTOR
# =============================================================================

# Stem -> Element
STEM_TO_ELEMENT = {
    "Jia": "Holz", "Yi": "Holz",
    "Bing": "Feuer", "Ding": "Feuer",
    "Wu": "Erde", "Ji": "Erde",
    "Geng": "Metall", "Xin": "Metall",
    "Ren": "Wasser", "Gui": "Wasser",
}

# Hidden stems in branches with traditional weights
# Main Qi: 1.0 / Middle Qi: 0.5 / Residual Qi: 0.3
BRANCH_HIDDEN = {
    "Zi":   [("Wasser", 1.0)],
    "Chou": [("Erde", 1.0), ("Wasser", 0.5), ("Metall", 0.3)],
    "Yin":  [("Holz", 1.0), ("Feuer", 0.5), ("Erde", 0.3)],
    "Mao":  [("Holz", 1.0)],
    "Chen": [("Erde", 1.0), ("Holz", 0.5), ("Wasser", 0.3)],
    "Si":   [("Feuer", 1.0), ("Metall", 0.5), ("Erde", 0.3)],
    "Wu":   [("Feuer", 1.0), ("Erde", 0.5)],
    "Wei":  [("Erde", 1.0), ("Feuer", 0.5), ("Holz", 0.3)],
    "Shen": [("Metall", 1.0), ("Wasser", 0.5), ("Erde", 0.3)],
    "You":  [("Metall", 1.0)],
    "Xu":   [("Erde", 1.0), ("Metall", 0.5), ("Feuer", 0.3)],
    "Hai":  [("Wasser", 1.0), ("Holz", 0.5)],
}


def calculate_wuxing_from_bazi(pillars: Dict[str, Dict[str, str]]) -> WuXingVector:
    """
    Extract Wu-Xing vector from BaZi pillars.

    Uses direct list mutation (not per-iteration object creation).
    """
    values = [0.0, 0.0, 0.0, 0.0, 0.0]

    for _pillar_name, pillar_data in pillars.items():
        stem = pillar_data.get("stem", pillar_data.get("stamm", ""))
        branch = pillar_data.get("branch", pillar_data.get("zweig", ""))

        if stem in STEM_TO_ELEMENT:
            values[WUXING_INDEX[STEM_TO_ELEMENT[stem]]] += 1.0

        if branch in BRANCH_HIDDEN:
            for elem, weight in BRANCH_HIDDEN[branch]:
                values[WUXING_INDEX[elem]] += weight

    return WuXingVector(*values)


# =============================================================================
# HARMONY INDEX (Cosine Similarity)
# =============================================================================

def calculate_harmony_index(
    western_vector: WuXingVector,
    bazi_vector: WuXingVector,
) -> Dict[str, Any]:
    """
    Cosine similarity between Western and BaZi Wu-Xing vectors.

    Range for non-negative vectors: [0, 1].
    """
    w = western_vector.to_list()
    b = bazi_vector.to_list()
    mag_w = sqrt(sum(x ** 2 for x in w))
    mag_b = sqrt(sum(x ** 2 for x in b))

    if mag_w == 0 or mag_b == 0:
        harmony = 0.0
    else:
        dot = sum(a * c for a, c in zip(w, b))
        harmony = dot / (mag_w * mag_b)

    return {
        "harmony_index": round(harmony, 4),
        "interpretation": interpret_harmony(harmony),
        "method": "cosine_similarity",
        "western_vector": western_vector.normalize().to_dict(),
        "bazi_vector": bazi_vector.normalize().to_dict(),
    }


def interpret_harmony(h: float) -> str:
    if h >= 0.8:
        return "Starke Resonanz - Westliche und oestliche Matrix stehen in perfekter Harmonie"
    elif h >= 0.6:
        return "Gute Harmonie - Die Energien unterstuetzen sich gegenseitig"
    elif h >= 0.4:
        return "Moderate Balance - Unterschiedliche Schwerpunkte, aber keine Konflikte"
    elif h >= 0.2:
        return "Gespannte Harmonie - Teils komplementaer, teils divergierend"
    else:
        return "Divergenz - Westliche und oestliche Energien arbeiten in unterschiedliche Richtungen"


# =============================================================================
# ELEMENTAL BALANCE (Shannon Entropy) — replaces phantom "cosmic_state"
# =============================================================================

def calculate_elemental_balance(vector: WuXingVector) -> float:
    """
    Shannon entropy of the element distribution, normalized to [0, 1].

    - 1.0 = perfectly balanced (equal proportions)
    - 0.0 = all energy in one element (maximum imbalance)

    H_norm = -sum(p_i * log2(p_i)) / log2(5)
    """
    props = vector.proportions()
    max_entropy = log2(5)  # ~2.3219
    entropy = 0.0
    for p in props:
        if p > 0:
            entropy -= p * log2(p)
    return round(entropy / max_entropy, 4) if max_entropy > 0 else 0.0


# =============================================================================
# EQUATION OF TIME
# =============================================================================

def equation_of_time(day_of_year: int, use_precise: bool = True) -> float:
    """
    Equation of Time in minutes.

    Precise formula: NOAA Fourier series.
    Range: approx -14.2 to +16.4 minutes.
    """
    if use_precise:
        gamma = 2 * pi * (day_of_year - 1) / 365.0
        E = 229.18 * (
            0.000075
            + 0.001868 * cos(gamma)
            - 0.032077 * sin(gamma)
            - 0.014615 * cos(2 * gamma)
            - 0.040849 * sin(2 * gamma)
        )
        return round(E, 3)
    else:
        B = radians(360 * (day_of_year - 81) / 365)
        E = 9.87 * sin(2 * B) - 7.53 * cos(B) - 1.5 * sin(B)
        return round(E, 2)


# =============================================================================
# TRUE SOLAR TIME
# =============================================================================

def true_solar_time(
    civil_time_hours: float,
    longitude_deg: float,
    day_of_year: int,
    timezone_offset_hours: float = None,
) -> float:
    """
    True Solar Time from civil clock time.

    TST = LMT + E_t
    LMT = UTC + lon/15
    UTC = civil - tz_offset

    Note: This gives the astronomically correct solar time at the
    observer's exact longitude.  For the 'standard meridian' variant
    used in most BaZi software, use true_solar_time_from_civil().
    """
    if timezone_offset_hours is not None:
        utc_hours = civil_time_hours - timezone_offset_hours
        lmt_hours = utc_hours + (longitude_deg / 15.0)
    else:
        lmt_hours = civil_time_hours

    E_t = equation_of_time(day_of_year) / 60.0
    TST = lmt_hours + E_t

    while TST < 0:
        TST += 24
    while TST >= 24:
        TST -= 24
    return round(TST, 4)


def true_solar_time_from_civil(
    civil_time_hours: float,
    longitude_deg: float,
    day_of_year: int,
    standard_meridian_deg: float = None,
) -> float:
    """
    True Solar Time using standard-meridian correction.

    TST = civil + (std_meridian - lon) * 4min/deg + E_t

    This is the formula most BaZi software uses.
    """
    if standard_meridian_deg is None:
        standard_meridian_deg = round(longitude_deg / 15) * 15

    longitude_correction_hours = (standard_meridian_deg - longitude_deg) * 4 / 60
    E_t_hours = equation_of_time(day_of_year) / 60.0
    TST = civil_time_hours + longitude_correction_hours + E_t_hours

    while TST < 0:
        TST += 24
    while TST >= 24:
        TST -= 24
    return round(TST, 4)


# =============================================================================
# MAIN FUSION ANALYSIS
# =============================================================================

def compute_fusion_analysis(
    birth_utc_dt: Any,
    latitude: float,
    longitude: float,
    bazi_pillars: Dict[str, Dict[str, str]],
    western_bodies: Dict[str, Dict[str, Any]],
    ascendant: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Complete Fusion Astrology Analysis.

    Args:
        birth_utc_dt: Birth datetime in UTC.
        latitude: Birth latitude.
        longitude: Birth longitude.
        bazi_pillars: BaZi pillars (year/month/day/hour).
        western_bodies: Planetary positions from compute_western_chart().
        ascendant: Ascendant degree for sect determination.
    """
    # 1. Wu-Xing vectors
    western_wuxing = calculate_wuxing_vector_from_planets(
        western_bodies, ascendant=ascendant
    )
    bazi_wuxing = calculate_wuxing_from_bazi(bazi_pillars)

    # 2. Harmony (cosine similarity)
    harmony = calculate_harmony_index(western_wuxing, bazi_wuxing)

    # 3. Normalized for comparison
    western_normalized = western_wuxing.normalize()
    bazi_normalized = bazi_wuxing.normalize()

    elemental_comparison = {}
    for elem in WUXING_ORDER:
        w_val = getattr(western_normalized, elem.lower())
        b_val = getattr(bazi_normalized, elem.lower())
        elemental_comparison[elem] = {
            "western": round(w_val, 3),
            "bazi": round(b_val, 3),
            "difference": round(w_val - b_val, 3),
        }

    # 4. Elemental Balance (Shannon entropy) — distinct from harmony
    combined_values = [
        w + b for w, b in zip(western_wuxing.to_list(), bazi_wuxing.to_list())
    ]
    combined_vector = WuXingVector(*combined_values)
    elemental_balance = calculate_elemental_balance(combined_vector)
    western_balance = calculate_elemental_balance(western_wuxing)
    bazi_balance = calculate_elemental_balance(bazi_wuxing)

    return {
        "wu_xing_vectors": {
            "western_planets": western_normalized.to_dict(),
            "bazi_pillars": bazi_normalized.to_dict(),
        },
        "harmony_index": harmony,
        "elemental_comparison": elemental_comparison,
        "elemental_balance": {
            "combined": elemental_balance,
            "western": western_balance,
            "bazi": bazi_balance,
            "interpretation": _interpret_balance(elemental_balance),
        },
        "fusion_interpretation": generate_fusion_interpretation(
            harmony["harmony_index"],
            elemental_comparison,
            western_wuxing,
            bazi_wuxing,
        ),
    }


def _interpret_balance(b: float) -> str:
    if b >= 0.9:
        return "Ausgezeichnete Balance - Alle fuenf Elemente sind nahezu gleich verteilt"
    elif b >= 0.75:
        return "Gute Balance - Leichte Schwerpunkte, insgesamt ausgewogen"
    elif b >= 0.5:
        return "Moderate Balance - Deutliche Schwerpunkte auf wenigen Elementen"
    else:
        return "Ungleichgewicht - Starke Konzentration auf ein oder zwei Elemente"


def generate_fusion_interpretation(
    harmony: float,
    comparison: Dict[str, Dict[str, float]],
    western: WuXingVector,
    bazi: WuXingVector,
) -> str:
    w_dict = western.to_dict()
    b_dict = bazi.to_dict()
    w_dominant = max(w_dict, key=w_dict.get)
    b_dominant = max(b_dict, key=b_dict.get)

    lines = [
        f"Harmonie-Index: {harmony:.2%}",
        interpret_harmony(harmony),
        "",
        f"Westliche Dominanz: {w_dominant}",
        f"Oestliche Dominanz: {b_dominant}",
        "",
    ]

    if harmony >= 0.6:
        lines.append("Ihre westliche und oestliche Chart stehen in starker Resonanz.")
        lines.append("Die Energien ergaenzen sich harmonisch.")
    elif harmony >= 0.3:
        lines.append("Ihre Charts zeigen eine interessante Balance zwischen Ost und West.")
        lines.append("Es gibt Spannungen, aber auch Wachstumspotential.")
    else:
        lines.append("Ihre westliche und oestliche Energie arbeiten in unterschiedliche Richtungen.")
        lines.append("Integration erfordert bewusste Arbeit.")

    return "\n".join(lines)
