"""
Western astrology chart computation.

Uses SwissEphBackend for all calculations — ephemeris mode (SWIEPH vs
Moshier) is auto-detected, not hardcoded.
"""
from __future__ import annotations
from typing import Dict, Any
import swisseph as swe
from .ephemeris import SwissEphBackend, datetime_utc_to_jd_ut

PLANETS = {
    "Sun": swe.SUN,
    "Moon": swe.MOON,
    "Mercury": swe.MERCURY,
    "Venus": swe.VENUS,
    "Mars": swe.MARS,
    "Jupiter": swe.JUPITER,
    "Saturn": swe.SATURN,
    "Uranus": swe.URANUS,
    "Neptune": swe.NEPTUNE,
    "Pluto": swe.PLUTO,
    "Chiron": swe.CHIRON,
    "Lilith": swe.MEAN_APOG,
    "NorthNode": swe.TRUE_NODE,
}


def compute_western_chart(
    birth_utc_dt: Any,
    lat: float,
    lon: float,
    alt: float = 0.0,
    ephe_path: str = None,
) -> Dict[str, Any]:
    """
    Compute western chart: planet positions + houses + angles.

    Uses a single SwissEphBackend instance that auto-selects
    SWIEPH (data files) or Moshier (built-in) mode.

    Returns dict with: jd_ut, ephemeris_mode, house_system,
    bodies, houses, angles.
    """
    backend = SwissEphBackend(ephe_path=ephe_path)
    jd_ut = datetime_utc_to_jd_ut(birth_utc_dt)

    # -- Bodies --
    bodies: Dict[str, Any] = {}
    for name, pid in PLANETS.items():
        bodies[name] = backend.calc_body_ut(jd_ut, pid)

    # -- Houses --
    house_data = backend.calc_houses(jd_ut, lat, lon)

    return {
        "jd_ut": jd_ut,
        "ephemeris_mode": backend.mode,
        "house_system": house_data["house_system"],
        "bodies": bodies,
        "houses": house_data["cusps"],
        "angles": house_data["angles"],
    }
