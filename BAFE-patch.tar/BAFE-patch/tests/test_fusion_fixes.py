"""
Strict tests for fusion.py fixes and ephemeris integration.

Tests are organized by bug/feature:
  1. Ephemeris: Moshier fallback produces valid astronomical results
  2. BUG-1: No more Moon-node double-counting
  3. BUG-2: Night chart detection is functional (Mercury changes element)
  4. BUG-3: elemental_balance != harmony_index (Shannon entropy)
  5. Equation of Time accuracy against NOAA reference
  6. True Solar Time consistency
  7. Hidden Stems reference correctness
  8. End-to-end fusion pipeline
"""
import pytest
from math import sqrt, log2, isclose
from datetime import datetime, timezone

# ── Imports under test ──

from bazi_engine.ephemeris import (
    SwissEphBackend,
    datetime_utc_to_jd_ut,
    jd_ut_to_datetime_utc,
    norm360,
)
from bazi_engine.western import compute_western_chart, PLANETS
from bazi_engine.fusion import (
    PLANET_TO_WUXING,
    WUXING_ORDER,
    WUXING_INDEX,
    WuXingVector,
    BRANCH_HIDDEN,
    STEM_TO_ELEMENT,
    is_night_chart,
    planet_to_wuxing,
    calculate_wuxing_vector_from_planets,
    calculate_wuxing_from_bazi,
    calculate_harmony_index,
    calculate_elemental_balance,
    equation_of_time,
    true_solar_time,
    true_solar_time_from_civil,
    compute_fusion_analysis,
)


# =====================================================================
# 1. EPHEMERIS BACKEND
# =====================================================================

class TestEphemerisBackend:
    """SwissEphBackend works in Moshier mode without data files."""

    def test_backend_initializes(self):
        b = SwissEphBackend()
        assert b.mode in ("swieph", "moshier")

    def test_sun_longitude_range(self):
        b = SwissEphBackend()
        jd = datetime_utc_to_jd_ut(
            datetime(2024, 6, 21, 12, 0, 0, tzinfo=timezone.utc)
        )
        lon = b.sun_lon_deg_ut(jd)
        assert 0 <= lon < 360
        # Summer solstice: Sun near 90 deg (Cancer ingress)
        assert 88 < lon < 92, f"Summer solstice Sun should be ~90 deg, got {lon}"

    def test_lichun_2024_date(self):
        """LiChun 2024 = Feb 4, ~08:27 UTC (known reference)."""
        b = SwissEphBackend()
        import swisseph as swe
        jd_start = swe.julday(2024, 1, 1, 0.0)
        jd_lichun = b.solcross_ut(315.0, jd_start)
        dt = jd_ut_to_datetime_utc(jd_lichun)
        assert dt.month == 2
        assert dt.day == 4
        # Within 10 minutes of known time (08:27 UTC)
        hours = dt.hour + dt.minute / 60
        assert abs(hours - 8.45) < 0.2, f"LiChun 2024 should be ~08:27 UTC, got {dt}"

    def test_delta_t_reasonable(self):
        b = SwissEphBackend()
        jd = datetime_utc_to_jd_ut(
            datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        )
        dt_sec = b.delta_t_seconds(jd)
        # Delta-T in 2024: ~69 seconds
        assert 60 < dt_sec < 80, f"Delta-T should be ~69s, got {dt_sec}"

    def test_calc_body_all_planets(self):
        """All planets in PLANETS dict compute without error."""
        b = SwissEphBackend()
        jd = datetime_utc_to_jd_ut(
            datetime(2024, 6, 15, 12, 0, 0, tzinfo=timezone.utc)
        )
        for name, pid in PLANETS.items():
            result = b.calc_body_ut(jd, pid)
            assert "error" not in result, f"{name}: {result.get('error')}"
            assert 0 <= result["longitude"] < 360
            assert result["zodiac_sign"] in range(12)

    def test_calc_houses_berlin(self):
        b = SwissEphBackend()
        jd = datetime_utc_to_jd_ut(
            datetime(2024, 2, 10, 13, 30, 0, tzinfo=timezone.utc)
        )
        h = b.calc_houses(jd, 52.52, 13.405)
        assert h["house_system"] in ("P", "O", "W")
        assert len(h["cusps"]) == 12
        asc = h["angles"]["Ascendant"]
        assert 0 <= asc < 360

    def test_jd_roundtrip(self):
        """datetime -> JD -> datetime roundtrip within 1 second."""
        original = datetime(2024, 7, 15, 14, 30, 45, tzinfo=timezone.utc)
        jd = datetime_utc_to_jd_ut(original)
        recovered = jd_ut_to_datetime_utc(jd)
        delta = abs((recovered - original).total_seconds())
        assert delta < 1.0, f"Roundtrip error: {delta}s"


# =====================================================================
# 2. BUG-1: MOON NODE DOUBLE-COUNTING
# =====================================================================

class TestMoonNodeFix:
    """TrueNorthNode must NOT appear in the Wu-Xing mapping or PLANETS."""

    def test_no_true_north_node_in_mapping(self):
        assert "TrueNorthNode" not in PLANET_TO_WUXING, \
            "TrueNorthNode must be removed from PLANET_TO_WUXING"

    def test_no_true_north_node_in_planets(self):
        assert "TrueNorthNode" not in PLANETS, \
            "TrueNorthNode must be removed from western.PLANETS"

    def test_north_node_counted_once(self):
        """Wood gets exactly +1.0 from NorthNode, not +2.0."""
        bodies = {
            "NorthNode": {"longitude": 50.0, "is_retrograde": False},
        }
        vec = calculate_wuxing_vector_from_planets(bodies)
        assert vec.holz == 1.0, f"NorthNode should contribute 1.0 to Holz, got {vec.holz}"

    def test_total_planet_count(self):
        """Western chart has exactly 13 bodies (not 14)."""
        dt = datetime(2024, 6, 15, 12, 0, 0, tzinfo=timezone.utc)
        chart = compute_western_chart(dt, 52.52, 13.405)
        bodies_without_errors = {
            k: v for k, v in chart["bodies"].items() if "error" not in v
        }
        assert len(bodies_without_errors) == 13, \
            f"Expected 13 bodies, got {len(bodies_without_errors)}: {list(bodies_without_errors.keys())}"


# =====================================================================
# 3. BUG-2: NIGHT CHART DETECTION
# =====================================================================

class TestNightChartFix:

    def test_night_chart_with_ascendant(self):
        """Sun below horizon = night chart."""
        # ASC at 90 deg, Sun at 300 deg (below horizon: between DSC=270 and ASC=90)
        assert is_night_chart(300.0, ascendant=90.0) is True

    def test_day_chart_with_ascendant(self):
        """Sun above horizon = day chart."""
        # ASC at 90 deg, Sun at 180 deg (above horizon)
        assert is_night_chart(180.0, ascendant=90.0) is False

    def test_no_ascendant_returns_false(self):
        """Without Ascendant, always assumes day chart."""
        assert is_night_chart(300.0, ascendant=None) is False

    def test_mercury_day_is_earth(self):
        assert planet_to_wuxing("Mercury", is_night=False) == "Erde"

    def test_mercury_night_is_metal(self):
        assert planet_to_wuxing("Mercury", is_night=True) == "Metall"

    def test_mercury_actually_changes_with_ascendant(self):
        """Mercury element flips when ascendant is provided to a night chart."""
        sun_lon = 300.0  # Below horizon when ASC=90

        # Day chart (no ascendant)
        bodies_day = {
            "Sun": {"longitude": sun_lon, "is_retrograde": False},
            "Mercury": {"longitude": 310.0, "is_retrograde": False},
        }
        vec_day = calculate_wuxing_vector_from_planets(bodies_day, ascendant=None)

        # Night chart (with ascendant)
        vec_night = calculate_wuxing_vector_from_planets(bodies_day, ascendant=90.0)

        # In day chart: Mercury -> Erde
        assert vec_day.erde == 1.0, "Day: Mercury should map to Erde"
        assert vec_day.metall == 0.0, "Day: no Metall from Mercury"

        # In night chart: Mercury -> Metall
        assert vec_night.metall == 1.0, "Night: Mercury should map to Metall"
        # Sun still maps to Feuer in both cases
        assert vec_day.feuer == 1.0
        assert vec_night.feuer == 1.0

    def test_ascendant_passed_through_compute_western_chart(self):
        """compute_western_chart returns Ascendant in angles."""
        dt = datetime(2024, 2, 10, 13, 30, 0, tzinfo=timezone.utc)
        chart = compute_western_chart(dt, 52.52, 13.405)
        asc = chart["angles"]["Ascendant"]
        assert isinstance(asc, float)
        assert 0 <= asc < 360


# =====================================================================
# 4. BUG-3: ELEMENTAL BALANCE != HARMONY INDEX
# =====================================================================

class TestElementalBalanceFix:

    def test_balance_is_not_harmony(self):
        """Shannon entropy and cosine similarity are fundamentally different metrics."""
        w = WuXingVector(3.0, 3.0, 1.0, 1.0, 4.0)
        b = WuXingVector(2.0, 1.5, 3.3, 1.0, 2.8)

        harmony = calculate_harmony_index(w, b)["harmony_index"]
        combined = WuXingVector(*[
            a + c for a, c in zip(w.to_list(), b.to_list())
        ])
        balance = calculate_elemental_balance(combined)

        assert harmony != balance, \
            f"harmony_index ({harmony}) and elemental_balance ({balance}) must differ"

    def test_perfect_balance_is_1(self):
        """Equal distribution -> entropy = 1.0."""
        v = WuXingVector(2.0, 2.0, 2.0, 2.0, 2.0)
        assert calculate_elemental_balance(v) == 1.0

    def test_single_element_is_0(self):
        """All energy in one element -> entropy = 0.0."""
        v = WuXingVector(5.0, 0.0, 0.0, 0.0, 0.0)
        assert calculate_elemental_balance(v) == 0.0

    def test_balance_monotonic(self):
        """More spread-out distribution -> higher balance."""
        concentrated = WuXingVector(10.0, 1.0, 0.0, 0.0, 0.0)
        spread = WuXingVector(3.0, 2.5, 2.0, 1.5, 2.0)
        assert calculate_elemental_balance(spread) > calculate_elemental_balance(concentrated)

    def test_zero_vector_returns_0(self):
        v = WuXingVector.zero()
        assert calculate_elemental_balance(v) == 0.0

    def test_balance_range(self):
        """Balance is always in [0, 1]."""
        import random
        random.seed(42)
        for _ in range(100):
            vals = [random.uniform(0, 10) for _ in range(5)]
            v = WuXingVector(*vals)
            b = calculate_elemental_balance(v)
            assert 0.0 <= b <= 1.0, f"Balance {b} out of range for {vals}"


# =====================================================================
# 5. EQUATION OF TIME — NOAA REFERENCE
# =====================================================================

class TestEquationOfTime:
    """EoT values compared against NOAA Solar Calculator."""

    @pytest.mark.parametrize("day,expected,tolerance", [
        (43,  -14.2, 0.5),   # Feb 12 (near minimum)
        (135,  +3.7, 0.5),   # May 15
        (208,  -6.5, 0.5),   # Jul 27
        (307, +16.4, 0.5),   # Nov 3 (near maximum)
    ])
    def test_eot_noaa_reference(self, day, expected, tolerance):
        result = equation_of_time(day)
        assert abs(result - expected) < tolerance, \
            f"Day {day}: EoT={result}, expected ~{expected} (±{tolerance})"

    def test_eot_range(self):
        """Full year should stay within known bounds."""
        values = [equation_of_time(d) for d in range(1, 366)]
        assert min(values) > -16.0
        assert max(values) < 18.0


# =====================================================================
# 6. TRUE SOLAR TIME CONSISTENCY
# =====================================================================

class TestTrueSolarTime:

    def test_tst_berlin_feb10(self):
        """Berlin 14:30 on Feb 10: TST should be ~14:22 (meridian method)."""
        tst = true_solar_time_from_civil(14.5, 13.405, 41, 15.0)
        # Expected: 14.5 + (15-13.405)*4/60 + EoT/60 ≈ 14.37
        assert 14.0 < tst < 15.0

    def test_tst_from_civil_at_standard_meridian(self):
        """At standard meridian, longitude correction = 0."""
        tst = true_solar_time_from_civil(12.0, 15.0, 172, 15.0)
        eot = equation_of_time(172) / 60.0
        expected = 12.0 + eot
        assert isclose(tst, expected % 24, abs_tol=0.001)

    def test_lmt_method_at_meridian(self):
        """LMT method at lon=15 with tz=+1: both methods should agree."""
        day = 100
        lon = 15.0
        tz = 1.0
        tst_lmt = true_solar_time(12.0, lon, day, tz)
        tst_civil = true_solar_time_from_civil(12.0, lon, day, lon)
        assert isclose(tst_lmt, tst_civil, abs_tol=0.01), \
            f"At standard meridian: LMT={tst_lmt}, Civil={tst_civil}"


# =====================================================================
# 7. HIDDEN STEMS REFERENCE CORRECTNESS
# =====================================================================

class TestHiddenStems:
    """Validate hidden stems against standard reference (王黛林)."""

    REFERENCE_STEMS = {
        "Zi":   ["Gui"],
        "Chou": ["Ji", "Gui", "Xin"],
        "Yin":  ["Jia", "Bing", "Wu"],
        "Mao":  ["Yi"],
        "Chen": ["Wu", "Yi", "Gui"],
        "Si":   ["Bing", "Geng", "Wu"],
        "Wu":   ["Ding", "Ji"],
        "Wei":  ["Ji", "Ding", "Yi"],
        "Shen": ["Geng", "Ren", "Wu"],
        "You":  ["Xin"],
        "Xu":   ["Wu", "Xin", "Ding"],
        "Hai":  ["Ren", "Jia"],
    }

    @pytest.mark.parametrize("branch", list(REFERENCE_STEMS.keys()))
    def test_hidden_stem_elements(self, branch):
        ref_elems = [STEM_TO_ELEMENT[s] for s in self.REFERENCE_STEMS[branch]]
        code_elems = [e for e, _w in BRANCH_HIDDEN[branch]]
        assert code_elems == ref_elems, \
            f"{branch}: code={code_elems}, reference={ref_elems}"


# =====================================================================
# 8. VECTOR MATH INVARIANTS
# =====================================================================

class TestVectorMath:

    def test_cosine_similarity_identical_is_1(self):
        v = WuXingVector(3.0, 2.0, 1.0, 4.0, 2.0)
        h = calculate_harmony_index(v, v)
        assert isclose(h["harmony_index"], 1.0, abs_tol=0.001)

    def test_cosine_similarity_orthogonal_is_0(self):
        a = WuXingVector(1.0, 0.0, 0.0, 0.0, 0.0)
        b = WuXingVector(0.0, 1.0, 0.0, 0.0, 0.0)
        h = calculate_harmony_index(a, b)
        assert isclose(h["harmony_index"], 0.0, abs_tol=0.001)

    def test_normalize_magnitude_is_1(self):
        v = WuXingVector(3.0, 4.0, 0.0, 0.0, 0.0)
        n = v.normalize()
        assert isclose(n.magnitude(), 1.0, abs_tol=1e-10)

    def test_zero_vector_normalize_safe(self):
        v = WuXingVector.zero()
        n = v.normalize()
        assert n.magnitude() == 0.0

    def test_positive_vectors_cosine_non_negative(self):
        """For non-negative vectors, cosine similarity >= 0."""
        import random
        random.seed(99)
        for _ in range(200):
            a = WuXingVector(*[random.uniform(0, 10) for _ in range(5)])
            b = WuXingVector(*[random.uniform(0, 10) for _ in range(5)])
            h = calculate_harmony_index(a, b)["harmony_index"]
            assert h >= 0.0, f"Negative cosine for positive vectors: {h}"


# =====================================================================
# 9. END-TO-END FUSION PIPELINE
# =====================================================================

class TestFusionEndToEnd:

    def _make_pillars(self):
        """JiaChen BingYin JiaChen XinWei (Berlin 2024-02-10 14:30)"""
        return {
            "year":  {"stem": "Jia",  "branch": "Chen"},
            "month": {"stem": "Bing", "branch": "Yin"},
            "day":   {"stem": "Jia",  "branch": "Chen"},
            "hour":  {"stem": "Xin",  "branch": "Wei"},
        }

    def test_full_pipeline(self):
        dt_utc = datetime(2024, 2, 10, 13, 30, 0, tzinfo=timezone.utc)
        chart = compute_western_chart(dt_utc, 52.52, 13.405)
        asc = chart["angles"]["Ascendant"]

        result = compute_fusion_analysis(
            birth_utc_dt=dt_utc,
            latitude=52.52,
            longitude=13.405,
            bazi_pillars=self._make_pillars(),
            western_bodies=chart["bodies"],
            ascendant=asc,
        )

        # Structure checks
        assert "harmony_index" in result
        assert "elemental_balance" in result
        assert "wu_xing_vectors" in result
        assert "fusion_interpretation" in result

        # No cosmic_state
        assert "cosmic_state" not in result

        # Value range checks
        hi = result["harmony_index"]["harmony_index"]
        assert 0.0 <= hi <= 1.0

        eb = result["elemental_balance"]["combined"]
        assert 0.0 <= eb <= 1.0

        # They are different metrics
        assert hi != eb

    def test_bazi_wuxing_vector_sums_correctly(self):
        """BaZi vector total should equal stems + hidden stems weights."""
        pillars = self._make_pillars()
        vec = calculate_wuxing_from_bazi(pillars)

        # 4 stems = 4.0
        # Chen hidden: Erde 1.0 + Holz 0.5 + Wasser 0.3 = 1.8 (twice)
        # Yin hidden: Holz 1.0 + Feuer 0.5 + Erde 0.3 = 1.8
        # Wei hidden: Erde 1.0 + Feuer 0.5 + Holz 0.3 = 1.8
        # Total stems: 4.0
        # Total hidden: 1.8 + 1.8 + 1.8 + 1.8 = 7.2
        expected_total = 4.0 + 1.8 * 4
        assert isclose(vec.total(), expected_total, abs_tol=0.01), \
            f"BaZi total: {vec.total()}, expected {expected_total}"

    def test_western_vector_total_is_planet_count(self):
        """Without retrograde weighting, total should equal number of planets."""
        dt_utc = datetime(2024, 2, 10, 13, 30, 0, tzinfo=timezone.utc)
        chart = compute_western_chart(dt_utc, 52.52, 13.405)

        valid_bodies = {
            k: v for k, v in chart["bodies"].items() if "error" not in v
        }
        vec = calculate_wuxing_vector_from_planets(
            valid_bodies, use_retrograde_weight=False
        )
        assert isclose(vec.total(), len(valid_bodies), abs_tol=0.01), \
            f"Western total: {vec.total()}, bodies: {len(valid_bodies)}"


# =====================================================================
# 10. API ENDPOINT REGRESSION (FastAPI TestClient)
# =====================================================================

class TestAPIEndpoints:

    @pytest.fixture
    def client(self):
        from fastapi.testclient import TestClient
        from bazi_engine.app import app
        return TestClient(app)

    def test_western_endpoint_has_13_bodies(self, client):
        resp = client.post("/calculate/western", json={
            "date": "2024-06-15T12:00:00",
            "tz": "Europe/Berlin",
            "lon": 13.405, "lat": 52.52,
        })
        assert resp.status_code == 200
        bodies = resp.json()["bodies"]
        assert "TrueNorthNode" not in bodies
        assert "NorthNode" in bodies
        assert len(bodies) == 13

    def test_western_endpoint_has_ephemeris_mode(self, client):
        resp = client.post("/calculate/western", json={
            "date": "2024-06-15T12:00:00",
            "tz": "Europe/Berlin",
            "lon": 13.405, "lat": 52.52,
        })
        assert resp.status_code == 200
        assert resp.json()["ephemeris_mode"] in ("swieph", "moshier")

    def test_fusion_endpoint_no_cosmic_state(self, client):
        resp = client.post("/calculate/fusion", json={
            "date": "2024-02-10T14:30:00",
            "tz": "Europe/Berlin",
            "lon": 13.405, "lat": 52.52,
            "bazi_pillars": {
                "year":  {"stem": "Jia",  "branch": "Chen"},
                "month": {"stem": "Bing", "branch": "Yin"},
                "day":   {"stem": "Jia",  "branch": "Chen"},
                "hour":  {"stem": "Xin",  "branch": "Wei"},
            },
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "cosmic_state" not in data
        assert "elemental_balance" in data
        assert 0 <= data["elemental_balance"]["combined"] <= 1
