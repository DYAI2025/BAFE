# How to apply this patch

1. Clone your repo:
   git clone https://github.com/DYAI2025/BAFE.git
   cd BAFE

2. Copy all files from this archive into the repo root:
   cp -r bazi_engine/ api/ tests/ /path/to/BAFE/

3. Run tests:
   pip install -r requirements.txt
   python -m pytest tests/ -v

4. Commit and push:
   git add -A
   git commit -F COMMIT_MESSAGE.txt
   git push
